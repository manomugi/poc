package main

import (
	"fmt"
	"html/template"
	"net/http"
	"strings"	
	"encoding/json"	
	"bytes"
	"io/ioutil"
	"time"
	"errors"
	"sort"
	"github.com/google/uuid"    
	"github.com/strata-io/service-extension/idfabric"
	"github.com/strata-io/service-extension/log"
	"github.com/strata-io/service-extension/orchestrator"
)

type RequestID struct {
	Ts    int64  `json:"ts"`
	Appid string `json:"appid"`
	Uuid  string `json:"uuid"`
}

type GeoLocation struct {
    Name    string `json:"name"`
    Country string `json:"country"`
    State   string `json:"state"`
}

// To add a new Error Page
//  1. Add ErrorType to enum list
//  2. Add Error Message, status code, and redirect (if true), to generateErrorData function
//  3. Add url path to errorStateMap
// TODO: confirm go template inside html script tag functions as expected

// IsAuthenticated determines if the user is authenticated. Authentication status is
// derived by querying the session cache.
func IsAuthenticated(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) bool {
	logger := api.Logger()
	logger.Info("se", "determining if user is authenticated or not")

	session, err := api.Session()
	logger.Info("se", fmt.Sprintf("Session: %+v", session))
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return false
	}

	authenticationIDP, err := session.GetString("authenticationIdp")
	originalDomain, err := session.GetString("originalDomain")
	authenticated, err := session.GetBool(authenticationIDP + ".authenticated")
	if err != nil {
		logger.Error(
			"se", fmt.Sprintf("unable to retrieve session value '%s.authenticated'", authenticationIDP),
			"error", err.Error(),
		)
		return false
	}

	logger.Info("se", "Checking if user is authenticated...")
	if authenticated {
		logger.Info("se", fmt.Sprintf("user is authenticated with '%s'", authenticationIDP))
		if originalDomain != "gds.ey.com" {
			kosmoAuth, _ := session.GetString("1k.authenticated")
			logger.Info("se", fmt.Sprintf("Is user authenticated with '1k'? %s", kosmoAuth))

			if kosmoAuth != "true" {
				logger.Info("se", "Triggering 1k authentication now")

				idp1k, err := api.IdentityProvider("1k")
				if err != nil {
					logger.Error("se", "unable to lookup 1k IDP", "error", err.Error())
					http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
					return false
				}

				email, _ := session.GetString("userEmail")
				loginHintOption := idfabric.WithLoginHint(email)
				idp1k.Login(rw, req, loginHintOption)

				return false // Redirecting, don't proceed further yet
			}
		}
		// Save email into final session key
		email, _ := session.GetString(authenticationIDP + ".email")
		session.SetString("GlobalLandingPage.email", email)
		err := session.Save()
		if err != nil {
			logger.Error("se", "unable to save session state", "error", err.Error())
		}
		
		claims, err := BuildTokenClaims(api, req)
        if err != nil {
            logger.Error("se", "error retrieving token claims", "error", err.Error())
            return false
        }
        
		EMAIL_1Kclaim, ok := claims["email_1k"].(string)
		if !ok {
			logger.Error("se", "failed to get EMAIL_1Kclaim from claims")
			return false
		}

 		Email_Entraclaim, _ := claims["email_Entra"].(string)
		EMAIL_WSSOclaim, _ := claims["email_WSSO"].(string)				
		var emailToCompare string
		if Email_Entraclaim != "" {
			emailToCompare = Email_Entraclaim
		} else if EMAIL_WSSOclaim != "" {
			emailToCompare = EMAIL_WSSOclaim
		}
		// Only compare if emailToCompare is not empty
		if emailToCompare != "" {
			if EMAIL_1Kclaim != emailToCompare {
				logMessage := fmt.Sprintf("EMAILID from 1kosmos SAML Claim and EMAILID from other IDP do not match. EMAILID IN 1k SAML CLAIM: %s, EMAILID IN OTHER IDP: %s", EMAIL_1Kclaim, emailToCompare)
				logger.Error("se", logMessage)
				return false
			}
		} else {
			logger.Info("se", "Skipping email comparison as both Email_Entraclaim and EMAIL_WSSOclaim are empty")
		}
		logger.Info("se", "Capturing event id")
        // 1kosmos block - start
        // Generate UUID and current time
        uuid := uuid.New().String()
        currentTime := time.Now().Unix()

        // Request ID
        requestID := RequestID{
            Ts:    currentTime,
            Appid: "com.strata.request",
            Uuid:  uuid,
        }

		secretProvider, err := api.SecretProvider()
		if err != nil {
			logger.Error("se", "Unable to get secret provider", "error", err.Error())
			return false
		}

		kosmosLicenseKey := secretProvider.GetString("1kosmosLicenseKey")
		ECDSAPrivateKey := secretProvider.GetString("ECDSAPrivateKey")
		ECDSAPublicKey := secretProvider.GetString("ECDSAPublicKey")
		GeolocationApiKey := secretProvider.GetString("GeolocationApiKey")
        // Call 1kosmos API - start encrypt
        oneKosmosLicenseKeyEncrypted := EncryptData(api, kosmosLicenseKey, ECDSAPrivateKey)
        requestIdEncrypted := EncryptData(api, toJSON(requestID), ECDSAPrivateKey)
        logger.Info("se", fmt.Sprintf("oneKosmosLicenseKeyEncrypted in IsAuthenticated method '%s'", oneKosmosLicenseKeyEncrypted))
        logger.Info("se", fmt.Sprintf("requestIdEncrypted in IsAuthenticated method '%s'", requestIdEncrypted))
        // Call 1kosmos API - end encrypt
        
        lat, lon, err := GetLatest1kEvent(api, oneKosmosLicenseKeyEncrypted, requestIdEncrypted, ECDSAPublicKey, req)
		if err != nil {			
			logger.Error("Error during GetLatest1kEvent:", err)
		} else {
			logger.Info("se", fmt.Sprintf("Latitude: '%s' and Longitude: '%s'", lat, lon))
			if lat == 0.0 || lon == 0.0 {
				logger.Error("se", "Latitude or Longitude is zero. User has not enabled location for Blockid app. Failing authentication.")
				return false
			}
		}
    
    	geoLocationResponse := GeolocationTranslation(api, lat, lon, GeolocationApiKey)
        logger.Info("se", fmt.Sprintf("Geolocation Translation API Response: '%s'", geoLocationResponse))
        	
    	var geoLocations []GeoLocation
		err = json.Unmarshal([]byte(geoLocationResponse), &geoLocations)
		if err != nil {
			logger.Error("Error unmarshalling geolocation response:", err)
		}

		if len(geoLocations) > 0 {
			name := geoLocations[0].Name
			country := geoLocations[0].Country
			state := geoLocations[0].State
			logger.Info("se", fmt.Sprintf("City: %s, Country: %s, State: %s", name, country, state))
			Test := "IN"
			if country != Test {
				logMessage := fmt.Sprintf("User is logging in from country: %s, which is not allowed to access the app.", country)
				logger.Error("se", logMessage)
				return false // Return false if they do not match
			}
		}		
		return true
	}

	logger.Info("se", "User not authenticated yet")
	return false
}

// Authenticate authenticates the user against the IDP that they select.
func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()

	// Allow developers to access the error pages directly
	DEBUG := false

	// assetFS used to get files for serving
	assetsFS, err := api.ServiceExtensionAssets().FS()
	if err != nil {
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return
	}

	// Session to store/retrieve data between redirects
	session, err := api.Session()
	logger.Info("se", fmt.Sprintf("Session: %+v", session))
	if err != nil {
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return
	}

	attemptedLogin, _ := session.GetBool("authenticationAttempted")
	// if Debug is true, allow developers to see the error pages directly
	// Uses OR truth table logic.
	//  if attemptedLogin OR DEBUG is true, then attemptedLogin is reassigned a true value
	attemptedLogin = attemptedLogin || DEBUG

	//  Maps each error type to a URL path
	//  Make sure to add error text and status code in generateErrorData() function below
	errorStateMap := map[string]ErrorState{
		"unknown":            ErrorUnknown,
		"noprovider":         ErrorNoIdPFound,
		"1kosmos":            Error1Kosmos,
		"invalidgeo":         ErrorInvalidGeolocation,
		"invalidbemsid":      ErrorInvalidBemsid,
		"invalidcitizenship": ErrorInvalidCitizenship,
		"proofingError":      ErrorMissingProofing,
		"errorLongTest":      ErrorLongTest,
	}

	if strings.Contains(req.URL.Path, "/errors/") {
		if attemptedLogin {
			error_type, _ := strings.CutPrefix(req.URL.Path, "/errors/")
			es, ok := errorStateMap[error_type]
			if !ok {
				es = ErrorUnknown
			}

			error_data := generateErrorData(es)
			logger.Info("se", "Error Data: ", fmt.Sprintf("%+v", error_data))
			error_template, err := template.ParseFS(assetsFS, "error.html")
			if err != nil {
				http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
			}

			error_template.Execute(rw, error_data)
			return
		} else {
			http.Redirect(rw, req, "/", http.StatusSeeOther)
			return
		}
	}

	// The folliwng string.Contains() checks on req.URL.Path are served from orchestrator subdomain
	if strings.Contains(req.URL.Path, "/style.css") {
		if req.Method == http.MethodGet {
			data, err := api.ServiceExtensionAssets().ReadFile("style.css")
			if err != nil {
				logger.Error("se", "Failed to serve CSS file", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			rw.Header().Set("Content-Type", "text/css")
			rw.Write(data)
			return
		}
	}

	if strings.Contains(req.URL.Path, "/images/") {
		if req.Method == http.MethodGet {
			filename, _ := strings.CutPrefix(req.URL.Path, "/images/")
			data, err := api.ServiceExtensionAssets().ReadFile(filename)
			filename_type_slice := strings.Split(filename, ".")
			filetype := filename_type_slice[len(filename_type_slice)-1]
			if err != nil {
				logger.Error("se", "failed to get image", "error", err.Error())
				// page can still load if this error occurs
				http.Error(rw, "Internal Error, Please Contact System Admin.", http.StatusInternalServerError)
			}
			rw.Header().Set("Content-Type", "image/"+filetype)
			rw.Write(data)
			return
		}

	}	

	// Serves the index file from proxy.* subdomain
	if req.Method == http.MethodGet {
		indextmpl, _ := template.ParseFS(assetsFS, "index.html")
		indextmpl.Execute(rw, nil)
		return
	}

	// process Post Req from proxy.* subdomain
	// Here if any errors occur, must use http.Redirect() to the corresponding
	//     error page on auth.* subdomain
	if req.Method != http.MethodPost {
		logger.Error("se", fmt.Sprintf("received unexpected request method '%s', expected POST", req.Method))
		return
	}

	logger.Info("se", "authenticating user")
	session.SetBool("authenticationAttempted", true)

	// get the User from the request
	user, err := parse_form_request(req)

	if err != nil {
		logger.Error("se", "failed to parse form from request", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusBadRequest), http.StatusBadRequest)
		http.Redirect(rw, req, "/errors/unknown", http.StatusSeeOther)
		return
	}

	// Here you would determine the IDP based on the domain
	// For example, you could have a map or a switch statement
	// idpDomainMap maps email domains to IDP identifiers
	logger.Info("se", fmt.Sprintf("Before getting IDP, User=%+v", user))
	authenticationIDP, err := get_idp_provider(user, logger)
	if err != nil {
		logger.Error("se", "unable to lookup idp", "error", err.Error())
		http.Redirect(rw, req, "/errors/noprovider", http.StatusSeeOther)
		return
	}

	logger.Info("se", fmt.Sprintf("User Email=%s", user.GetEmail()))
	err = session.SetString("authenticationIdp", authenticationIDP)
	if err != nil {
		logger.Error("se", "unable to save data to session", "error", err.Error())
		http.Redirect(rw, req, "/errors/unknown", http.StatusSeeOther)
		return
	}

	session.SetString("authenticationIdp", authenticationIDP)
	session.SetString("userEmail", user.GetEmail())
	session.SetString("originalDomain", user.Domain)
	err = session.Save()
	if err != nil {
		logger.Error("se", "unable to save api session", "error", err.Error())
		http.Redirect(rw, req, "/errors/unknown", http.StatusSeeOther)
		return
	}

	logger.Info("se", fmt.Sprintf("Prompting user to '%s' for authentication", authenticationIDP))

	idp, err := api.IdentityProvider(authenticationIDP)
	if err != nil {
		logger.Error("se", "Unable to get IdentityProvider object", "error", err.Error())
		http.Redirect(rw, req, "/errors/unknown", http.StatusSeeOther)
		return
	}

	loginHintOption := idfabric.WithLoginHint(user.GetEmail())
	idp.Login(rw, req, loginHintOption)
}

// Helper Functions and Structs
type User struct {
	Username string
	Domain   string
}

func (u User) GetEmail() string {
	return u.Username + "@" + u.Domain
}

func get_idp_provider(user User, logger log.Logger) (string, error) {
	// Here you would determine the IDP based on the domain
	// For example, you could have a map or a switch statement
	// idpDomainMap maps email domains to IDP identifiers
	idpDomainMap := map[string]string{
		"M365x46230084.onmicrosoft.com": "EntraID-OIDC"
    	"live.com": "EntraID-OIDC",
    	"auth0user.com": "Auth0DemoIDP",
    	"gmail.com": "1k",
		"boeing.com": "WSSO",
	}
	// Add more domain-to-IDP mappings here
	//	"pingonetrial.com": "PingOneCIAMTrial",
	//	"oktatrial.com": "OktaIDPTest",

	// Check if the domain exists in the idpDomainMap
	authenticationIDP, ok := idpDomainMap[user.Domain]

	logger.Info("se", "Inside get_idp_provider",
		fmt.Sprintf("user=%+v", user),
		fmt.Sprintf("authenticationIDP=%q, ok=%t", authenticationIDP, ok))

	if !ok {
		return "", fmt.Errorf("no idp provider")
	}

	return authenticationIDP, nil
}

func parse_form_request(req *http.Request) (User, error) {
	err := req.ParseForm()
	if err != nil {
		return User{"", ""}, err
	}
	email := req.Form.Get("username")
	split := strings.Split(email, "@")
	return User{split[0], split[1]}, nil
}

// Error State Related Code

type ErrorState int

const (
	ErrorUnknown ErrorState = iota
	ErrorInvalidCitizenship
	ErrorNoIdPFound
	ErrorInvalidBemsid
	ErrorInvalidGeolocation
	Error1Kosmos
	ErrorMissingProofing
	ErrorLongTest
	ErrorUnauthorized
)

type ErrorData struct {
	Message     string
	Code        uint
	CodeMessage string
	Redirect    bool
	RedirectURL string
}

func generateErrorData(es ErrorState) ErrorData {
	error_strings := map[ErrorState]string{
		ErrorUnknown:            "Looks like an error occured. Please contact helpdesk by phone or the link below for further assistance.",
		ErrorInvalidCitizenship: "Looks like you are accessing a resource only available to US citizens. If you think you have recieved this message in error please contact Helpdesk by phone or the link below.",
		ErrorNoIdPFound:         "Looks like we are unable to find the email domain you have entered. Please contact Helpdesk by phone or the link below.",
		ErrorInvalidBemsid:      "Looks like your BEMSID does not match what we have on file. Please contact Helpdesk by phone or the link below for assistance in logging in.",
		ErrorInvalidGeolocation: "Looks like you are trying to access a resource outside the USA. This resource is only available to users who currently reside on US soil.",
		Error1Kosmos:            "Error in Login from 1Kosmos. Please contact Helpdesk by phone or the link below for assistance logging in.",
		ErrorMissingProofing:    "Looks like you need to provide more information to access this resource. You will be re-directed to next step in 5 seconds.",
		ErrorLongTest:           "Lorem ipsum dolor sit amet consectetur adipiscing elit. Quisque faucibus ex sapien vitae pellentesque sem placerat. In id cursus mi pretium tellus duis convallis. Tempus leo eu aenean sed diam urna tempor. Pulvinar vivamus fringilla lacus nec metus bibendum egestas. Iaculis massa nisl malesuada lacinia integer nunc posuere. Ut hendrerit semper vel class aptent taciti sociosqu. Ad litora torquent per conubia nostra inceptos himenaeos. Lorem ipsum dolor sit amet consectetur adipiscing elit. Quisque faucibus ex sapien vitae pellentesque sem placerat. In id cursus mi pretium tellus duis convallis. Tempus leo eu aenean sed diam urna tempor.",
		ErrorUnauthorized:       "Looks like you are unauthorized to access this page. Please login to access.",
	}

	error_codes := map[ErrorState]uint{
		ErrorUnknown:            http.StatusInternalServerError,
		ErrorInvalidCitizenship: http.StatusUnauthorized,
		ErrorNoIdPFound:         http.StatusBadRequest,
		ErrorInvalidBemsid:      http.StatusBadRequest,
		ErrorInvalidGeolocation: http.StatusUnauthorized,
		Error1Kosmos:            http.StatusBadRequest,
		ErrorMissingProofing:    http.StatusSeeOther,
		ErrorLongTest:           http.StatusRequestURITooLong,
		ErrorUnauthorized:       http.StatusUnauthorized,
	}

	redirect_map := map[ErrorState]bool{
		Error1Kosmos:         true,
		ErrorMissingProofing: true,
	}

	redirect_urls := map[ErrorState]string{
		Error1Kosmos:         "https://example.com",
		ErrorMissingProofing: "https://example.com",
	}

	return ErrorData{
		error_strings[es],
		error_codes[es],
		http.StatusText(int(error_codes[es])),
		redirect_map[es],
		redirect_urls[es],
	}
}

func GetLatest1kEvent(api orchestrator.Orchestrator, oneKosmosLicenseKeyEncrypted string, requestIdEncrypted string, ECDSAPublicKey string, req *http.Request) (float64, float64, error) {
    logger := api.Logger()
    logger.Info("se", "Fetching latest 1Kosmos event - start")

    url := "https://blockid-pilot.1kosmos.net/reports/tenant/6241af5462a87240e1479b65/community/65f059f8534aab5c373a9887/events"
    method := "POST"

    // Call BuildTokenClaims to get user claims
    claims, err := BuildTokenClaims(api, req)
    if err != nil {
        logger.Error("se", "error retrieving token claims", "error", err.Error())
        return 0, 0, errors.New("error occurred")
    }

    // Extract the user email from claims
    userEmail, ok := claims["email_1k"].(string)
    LastName, ok := claims["LastName"].(string)
    
    logger.Info(fmt.Sprintf("The email id from saml claim : %s", userEmail))
    logger.Info(fmt.Sprintf("The LastName from saml claim is : %s", LastName))
    if !ok || userEmail == "" {
        logger.Error("se", "user email not found in token claims")
        return 0, 0, errors.New("error occurred")
    }

    
    fromTime := time.Now().Add(-1 * time.Hour).Format("2006-01-02 15:04:05.000")
	toTime := time.Now().Add(24 * time.Hour).Format("2006-01-02 15:04:05.000")

    // Constructing the JSON payload
    payload := map[string]interface{}{
        "pSize":  10,
        "pIndex": 0,
        "from":   fromTime,
        "to":     toTime,
        "query": map[string]string{
            "event_name":         "E_LOGIN_SUCCEEDED",
            "eventData.user_email": userEmail,
        },
        "text": `"event_name" "username"`,
    }

    // Convert payload to JSON
    jsonPayload, err := json.Marshal(payload)
    if err != nil {
        logger.Error("Error marshalling JSON payload:", err)
        return 0, 0, errors.New("error occurred")
    }

    client := &http.Client{}
    apiReq, err := http.NewRequest(method, url, bytes.NewBuffer(jsonPayload))
	if err != nil {
		logger.Error("Error creating request:", err)
		return 0, 0, errors.New("error occurred")
	}

    logger.Info("oneKosmosLicenseKeyEncrypted in GetLatest1kEvent: %s", oneKosmosLicenseKeyEncrypted)
    logger.Info("requestIdEncrypted in GetLatest1kEvent: %s", requestIdEncrypted)

    // Adding headers
    apiReq.Header.Set("Accept", "application/json")
    apiReq.Header.Set("Content-Type", "application/json")
    apiReq.Header.Set("licensekey", oneKosmosLicenseKeyEncrypted)
    apiReq.Header.Set("requestid", requestIdEncrypted)
    apiReq.Header.Set("publickey", ECDSAPublicKey)

    // Execute the request
    res, err := client.Do(apiReq)
    if err != nil {
        logger.Error("Error making request:", err)
        return 0, 0, errors.New("error occurred")
    }
    defer res.Body.Close()

    // Check HTTP status code
    if res.StatusCode != http.StatusOK {
        body, _ := ioutil.ReadAll(res.Body)
        logger.Error("Received non-200 response:", res.StatusCode, string(body))
        return 0, 0, errors.New("error occurred")
    }

    // Read response body
    body, err := ioutil.ReadAll(res.Body)
    if err != nil {
        logger.Error("Error reading response body:", err)
        return 0, 0, errors.New("error occurred")
    }

    // Log the raw response for debugging
    logger.Info("Response body:", string(body))

    // Parse response JSON
    var response struct {
        Data []struct {
            EventTS int64   `json:"event_ts"` // Change to string if needed
            AuthLat float64 `json:"auth_device_latitude"` // Change to float64
            AuthLon float64 `json:"auth_device_longitude"` // Change to float64
        } `json:"data"`
    }

    err = json.Unmarshal(body, &response)
    if err != nil {
        logger.Error("Error unmarshalling response:", err)
        return 0, 0, errors.New("error occurred")
    }

    // Sort events by timestamp in descending order
    sort.Slice(response.Data, func(i, j int) bool {
        return response.Data[i].EventTS > response.Data[j].EventTS
    })

    // Get the latest event if available
    if len(response.Data) > 0 {
        latestEvent := response.Data[0]
        seconds := latestEvent.EventTS / 1000
        t := time.Unix(seconds, 0)
        formattedTime := t.Format("2006-01-02 15:04:05")
        logger.Info("The latest event for user %s occurred at timestamp %s with a latitude of %f and longitude of %f", userEmail, formattedTime, latestEvent.AuthLat, latestEvent.AuthLon)
        logMessage := fmt.Sprintf("The latest event for user %s occurred at timestamp %s with a latitude of %f. and longitude of %f.", userEmail, formattedTime, latestEvent.AuthLat, latestEvent.AuthLon)
        logger.Info(logMessage)

        return latestEvent.AuthLat, latestEvent.AuthLon, nil
    }

    logger.Info("No events found.")
    return 0, 0, errors.New("No events found")
}

// Call 1Kosmos API - Encrypt input data
func EncryptData(api orchestrator.Orchestrator, inputData string, ecdsaPrivateKey string) string {
	logger := api.Logger()
	logger.Info("se", "Start Encrypt Data")	
	baseHeader := map[string]string{
		"Accept": "application/json",
	}
	
	publicKeyURL := "https://blockid-pilot.1kosmos.net/reports/publickeys"
	// Create a new HTTP client
	client := &http.Client{}
	// Create a new request
	req, err := http.NewRequest("GET", publicKeyURL, nil)
	if err != nil {
		logger.Error("Error creating request to fetch public key:", err)
		return ""
	}

	// Set the headers
	for key, value := range baseHeader {
		req.Header.Set(key, value)
	}

	// Execute the request
	res, err := client.Do(req)
	if err != nil {
		logger.Error("Error making request to fetch public key:", err)
		return ""
	}
	defer res.Body.Close()

	// Check HTTP status code
	if res.StatusCode != http.StatusOK {
		body, _ := ioutil.ReadAll(res.Body)
		logger.Error("Received non-200 response while fetching public key:", res.StatusCode, string(body))
		return ""
	}

	// Read response body
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		logger.Error("Error reading response body while fetching public key:", err)
		return ""
	}

	// Log the raw response for debugging
	logger.Info("Public Key Response body:", string(body))

	// Parse response JSON to get the public key
	var publicKeyResponse struct {
		PublicKey string `json:"publicKey"` // Adjust the field name based on the actual response structure
	}
	err = json.Unmarshal(body, &publicKeyResponse)
	if err != nil {
		logger.Error("Error unmarshalling public key response:", err)
		return ""
	}

	// Step 2: Define the payload for encryption
	url := "https://blockid-pilot.1kosmos.net/reports/ecdsa_helper/encrypt"
	method := "POST"
	payload := map[string]string{
		"dataStr":   inputData,
		"publicKey": publicKeyResponse.PublicKey, // Use the fetched public key
		"privateKey": ecdsaPrivateKey,
	}

	// Marshal the payload to JSON
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error("Error marshaling JSON:", err)
		return ""
	}

	// Create a new HTTP POST request
	req, err = http.NewRequest(method, url, bytes.NewBuffer(jsonData))
	if err != nil {
		logger.Error("Error creating request for encryption:", err)
		return ""
	}

	// Set the required headers
	req.Header.Set("accept", "application/json")
	req.Header.Set("Content-Type", "application/json")

	// Execute the request
	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Error executing request for encryption:", err)
		return ""
	}
	defer resp.Body.Close()

	// Read the response body
	body, err = ioutil.ReadAll(resp.Body)
	if err != nil {
		logger.Error("Error reading response body for encryption:", err)
		return ""
	}

	// Print the response body
	logger.Info("Encryption Response body: %s", string(body))

	// Unmarshal the JSON response into the ResponseData struct
	var responseData struct {
		EncryptedData string `json:"data"`
	}
	if err := json.Unmarshal(body, &responseData); err != nil {
		logger.Error("Erzror occurred during unmarshaling encryption response. Error: %s", err.Error())
		return ""
	}

	// Use the responseData struct
	logger.Info("Encrypted - responseData: %s", responseData)
	logger.Info("Encrypted - responseData.EncryptedData: %s", responseData.EncryptedData)
	logger.Info("se", "End Encrypt Data")
	return responseData.EncryptedData
}

func toJSON(v interface{}) string {
	bytes, err := json.Marshal(v)
	if err != nil {
		return ""
	}
	return string(bytes)
}

func BuildTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
    logger := api.Logger()
    session, err := api.Session()
    if err != nil {
        logger.Error("se", "unable to retrieve session", "error", err.Error())
        return nil, err
    }

    // Retrieve roles from the session
    roles, _ := session.GetString("1k.roles")

    // Retrieve the email from the session using the specific key
    userEmail1, _ := session.GetString("1k.mail") 
    LastName, _ := session.GetString("1k.LN")
    Mobile, _ := session.GetString("1k.Mobile")
    BEMSID, _ := session.GetString("1k.BEMSID")
    BEMSID_Entra, _ := session.GetString("EntraID-OIDC.BEMSID")
    userEmail2, _ := session.GetString("EntraID-OIDC.emailaddress") 
    userEmail3, _ := session.GetString("WSSO.mail")
    
    
    // Create a map to hold the claims
    claims := map[string]any{
        "scope": roles,
        "email_1k": userEmail1, // Include the email in the claims
        "LastName": LastName,
        "Mobile" : Mobile,
        "BEMSID_1K" : BEMSID,
        "BEMSID_Entra" : BEMSID_Entra,
        "email_Entra": userEmail2,
        "email_WSSO": userEmail3,
    }

    return claims, nil
}

func GeolocationTranslation(api orchestrator.Orchestrator, userLatitude float64, userLongitude float64, GeolocationApiKey string) string {
    logger := api.Logger()
	logger.Info("se", "Start GeolocationTranslation")

    lat := fmt.Sprintf("%f", userLatitude) // Convert float64 to string(userLatitude)
	lon := fmt.Sprintf("%f", userLongitude) // Convert float64 to string(userLongitude)
	apiKey := GeolocationApiKey
	logger.Info("GeolocationTranslation lat: %s", lat)
	logger.Info("GeolocationTranslation lon: %s", lon)
	url := fmt.Sprintf("https://api.api-ninjas.com/v1/reversegeocoding?lat=%s&lon=%s", lat, lon)

	client := &http.Client{}
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		logger.Error("Request creation failed:", err)		
		return ""
	}

	req.Header.Add("X-Api-Key", apiKey)

	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Request failed:", err)
		return ""
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		fmt.Printf("Error: %d\n", resp.StatusCode)
		bodyBytes, _ := ioutil.ReadAll(resp.Body)
		logger.Info("bodyBytes: %s", bodyBytes)
		return ""
	}

	bodyBytes, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		logger.Error("Reading body failed:", err)		
		return ""
	}

	fmt.Println(string(bodyBytes))
	logger.Info("GeolocationTranslation response: %s", string(bodyBytes))
	logger.Info("se", "End GeolocationTranslation")
	return string(bodyBytes)
}
