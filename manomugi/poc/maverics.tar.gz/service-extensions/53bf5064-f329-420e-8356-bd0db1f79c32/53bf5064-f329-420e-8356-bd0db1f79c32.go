package main

import (
    "encoding/base64"
	"fmt"
	"net/http"
	"strings"
	"time"	

	"github.com/strata-io/service-extension/orchestrator"
	"github.com/google/uuid"
)

func generateSAMLRequestWithIAL2(req *http.Request) (string, error) {
    
    samlID := fmt.Sprintf("_%s", uuid.NewString()) // Add a prefix "_" to match the working ID format
    fmt.Printf("Generated ID: %s\n", samlID)

    
     issueInstant := time.Now().UTC().Format("2006-01-02T15:04:05Z")
    fmt.Printf("Generated IssueInstant: %s\n", issueInstant)

    
    samlRequest := fmt.Sprintf(`<?xml version="1.0" encoding="UTF-8"?>
        <samlp:AuthnRequest xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol"
            xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion"
            ID="%s"
            Version="2.0"
            IssueInstant="%s"
            Destination="https://blockid-pilot.1kosmos.net/adminapi/community/ey-dev/sso"
            ProtocolBinding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST"
            AssertionConsumerServiceURL="https://maverics.sonarsystems.com/acs">
            <saml:Issuer>StrataSP_1kosmosidp</saml:Issuer>
            <samlp:NameIDPolicy AllowCreate="true"/>
            <samlp:RequestedAuthnContext Comparison="exact">
              <saml:AuthnContextClassRef>urn:oasis:names:tc:SAML:2.0:ac:classes:IAL2</saml:AuthnContextClassRef>
            </samlp:RequestedAuthnContext>
        </samlp:AuthnRequest>`,
        samlID,
        issueInstant,
    )

    fmt.Println("Generated SAML Request XML:\n", samlRequest)

    
    encodedRequest := base64.StdEncoding.EncodeToString([]byte(samlRequest))

    // Ensure padding is added to the Base64 string
    padding := len(encodedRequest) % 4
    if padding != 0 {
        encodedRequest += strings.Repeat("=", 4-padding)
    }

    fmt.Println("Encoded SAML Request:\n", encodedRequest)

    return encodedRequest, nil
}

func IsAuthenticated(api orchestrator.Orchestrator, _ http.ResponseWriter, _ *http.Request) bool {
	logger := api.Logger()
	logger.Debug("se", "Checking if user is authenticated")

	// In a real-world scenario, you would check for session or cookie validation here
	sessionProvider, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		return false
	}
	logger.Debug("se", "determining if user is authenticated")

	is1KosmosAuth, err := sessionProvider.GetString("1kosmos.authenticated")
	if err != nil {
		logger.Error("se", "unable to retrieve session value", "error", err.Error())
		return false
	}
	if is1KosmosAuth == "true" {
		return true
	}

	return false
}

func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Debug("se", "invoking IAL2 verification")

    if IsAuthenticated(api, rw, req) {
		// If the user is authenticated, skip redirection and proceed with next steps
		logger.Debug("se", "User is already authenticated")
		http.Redirect(rw, req, "/success", http.StatusFound) // Replace with your success URL or next step
		return
	}

	
	samlRequest, err := generateSAMLRequestWithIAL2(req)
	if err != nil {
		logger.Error("se", "failed to generate SAML request", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return
	}
	logger.Debug("se", "Generated SAML Request with IAL2", "request", samlRequest)

	
	redirectTo1Kosmos(rw, req, samlRequest) // Passing the req parameter
}

func redirectTo1Kosmos(rw http.ResponseWriter, req *http.Request, samlRequest string) {
    // Construct the HTML form for HTTP-POST
    postForm := fmt.Sprintf(`
        <html>
        <body onload="document.forms[0].submit()">
            <form method="POST" action="https://blockid-pilot.1kosmos.net/adminapi/community/ey-dev/sso">
                <input type="hidden" name="SAMLRequest" value="%s" />
            </form>
        </body>
        </html>
    `, samlRequest)

    // Write the HTML form to the response
    rw.Header().Set("Content-Type", "text/html")
    rw.WriteHeader(http.StatusOK)
    rw.Write([]byte(postForm))
}
