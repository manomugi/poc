package main

import (
	"fmt"
	"encoding/json"
	"net/http"
	"strings"
	"bytes"
	"io/ioutil"
	"time"
	"errors"
	"github.com/google/uuid"
	"github.com/strata-io/service-extension/orchestrator"
	"github.com/strata-io/service-extension/idfabric"
    "sort"
)

type RequestID struct {
	Ts    int64  `json:"ts"`
	Appid string `json:"appid"`
	Uuid  string `json:"uuid"`
}

type GeoLocation struct {
    Name    string `json:"name"`
    Country string `json:"country"`
    State   string `json:"state"`
}

func Authenticate(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
	logger := api.Logger()
	logger.Info("se", "Geolocation_Flow-authenticating user")

	if req.Method == http.MethodGet {
		// Serve login page
		assets := api.ServiceExtensionAssets()
		idpForm, err := assets.ReadFile("Login.html")
		if err != nil {
			logger.Error("se", "failed to read login page", "error", err.Error())
			http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
			return
		}
		_, _ = rw.Write(idpForm)
		return
	}

	if req.Method != http.MethodPost {
		logger.Error("se", fmt.Sprintf("unexpected method '%s', expected POST", req.Method))
		http.Error(rw, http.StatusText(http.StatusBadRequest), http.StatusBadRequest)
		return
	}

	err := req.ParseForm()
	if err != nil {
		logger.Error("se", "failed to parse login form", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return
	}

	email := req.Form.Get("email")
	domain := strings.Split(email, "@")[1]

	logger.Info("se", fmt.Sprintf("User with domain '%s' attempting to authenticate", domain))

	var idpDomainMap = map[string]string{
		"M365x46230084.onmicrosoft.com": "EntraIDP",
		"live.com":                      "EntraID-OIDC",
		"auth0user.com":                  "Auth0DemoIDP",
		"gmail.com":                        "1k",
	//	"gmail.com":                      "1KosmosIDP",
		"boeing.com":                     "WSSO",
	}

	authenticationIDP, ok := idpDomainMap[domain]
	if !ok {
		logger.Error("se", "no IDP found for domain", "domain", domain)
		http.Error(rw, "No IDP found for the provided domain", http.StatusBadRequest)
		return
	}

	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return
	}

	session.SetString("authenticationIdp", authenticationIDP)
	session.SetString("userEmail", email)
	session.SetString("originalDomain", domain) // Save domain for later
	err = session.Save()
	if err != nil {
		logger.Error("se", "unable to save session", "error", err.Error())
	}

	logger.Info("se", fmt.Sprintf("Prompting user to '%s' for authentication", authenticationIDP))

	idp, err := api.IdentityProvider(authenticationIDP)
	if err != nil {
		logger.Error("se", "unable to lookup IDP", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return
	}

	loginHintOption := idfabric.WithLoginHint(email)
	idp.Login(rw, req, loginHintOption)
}

func IsAuthenticated(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) bool {
	logger := api.Logger()
	logger.Info("se", "Geolocation_Flow-determining if user is authenticated or not")

	session, err := api.Session()
	if err != nil {
		logger.Error("se", "unable to retrieve session", "error", err.Error())
		http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
		return false
	}
	
	

	authenticationIDP, _ := session.GetString("authenticationIdp")
	originalDomain, _ := session.GetString("originalDomain")

	authenticated, _ := session.GetString(authenticationIDP + ".authenticated")
	logger.Info("se", fmt.Sprintf("Is user authenticated with '%s'? %s", authenticationIDP, authenticated))

	// If authenticated with the original IDP
	if authenticated == "true" {
		logger.Info("se", fmt.Sprintf("User authenticated with '%s'", authenticationIDP))

		
		if originalDomain != "gds.ey.com" {
			kosmoAuth, _ := session.GetString("1k.authenticated")
			logger.Info("se", fmt.Sprintf("Is user authenticated with '1k'? %s", kosmoAuth))

			if kosmoAuth != "true" {
				logger.Info("se", "Triggering 1k authentication now")

				idp1k, err := api.IdentityProvider("1k")
				if err != nil {
					logger.Error("se", "unable to lookup 1k IDP", "error", err.Error())
					http.Error(rw, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
					return false
				}

				email, _ := session.GetString("userEmail")
				loginHintOption := idfabric.WithLoginHint(email)
				idp1k.Login(rw, req, loginHintOption)

				return false // Redirecting, don't proceed further yet
			}
		}

		// Save email into final session key
		email, _ := session.GetString(authenticationIDP + ".email")
		session.SetString("Geolocation_Flow.email", email)
		err := session.Save()
		if err != nil {
			logger.Error("se", "unable to save session state", "error", err.Error())
		}
		
		claims, err := BuildTokenClaims(api, req)
        if err != nil {
            logger.Error("se", "error retrieving token claims", "error", err.Error())
            return false
        }

        
     EMAIL_1Kclaim, ok := claims["email_1k"].(string)
     if !ok {
    logger.Error("se", "failed to get EMAIL_1Kclaim from claims")
    return false
}

 Email_Entraclaim, _ := claims["email_Entra"].(string)
EMAIL_WSSOclaim, _ := claims["email_WSSO"].(string)
        
var emailToCompare string

if Email_Entraclaim != "" {
    emailToCompare = Email_Entraclaim
} else if EMAIL_WSSOclaim != "" {
    emailToCompare = EMAIL_WSSOclaim
}

// Only compare if emailToCompare is not empty
if emailToCompare != "" {
    if EMAIL_1Kclaim != emailToCompare {
        logMessage := fmt.Sprintf("EMAILID from 1kosmos SAML Claim and EMAILID from other IDP do not match. EMAILID IN 1k SAML CLAIM: %s, EMAILID IN OTHER IDP: %s", EMAIL_1Kclaim, emailToCompare)
        logger.Error("se", logMessage)
        return false
    }
} else {
    logger.Info("se", "Skipping email comparison as both Email_Entraclaim and EMAIL_WSSOclaim are empty")
}


		logger.Info("se", "Capturing event id")
        // 1kosmos block - start
        // Generate UUID and current time
        uuid := uuid.New().String()
        currentTime := time.Now().Unix()

        // Request ID
        requestID := RequestID{
            Ts:    currentTime,
            Appid: "com.strata.request",
            Uuid:  uuid,
        }


secretProvider, err := api.SecretProvider()
if err != nil {
    logger.Error("se", "Unable to get secret provider", "error", err.Error())
    return false
}

kosmosLicenseKey := secretProvider.GetString("1kosmosLicenseKey")
ECDSAPrivateKey := secretProvider.GetString("ECDSAPrivateKey")
ECDSAPublicKey := secretProvider.GetString("ECDSAPublicKey")
GeolocationApiKey := secretProvider.GetString("GeolocationApiKey")
        // Call 1kosmos API - start encrypt
        oneKosmosLicenseKeyEncrypted := EncryptData(api, kosmosLicenseKey, ECDSAPrivateKey)
        requestIdEncrypted := EncryptData(api, toJSON(requestID), ECDSAPrivateKey)
        logger.Info("se", fmt.Sprintf("oneKosmosLicenseKeyEncrypted in IsAuthenticated method '%s'", oneKosmosLicenseKeyEncrypted))
        logger.Info("se", fmt.Sprintf("requestIdEncrypted in IsAuthenticated method '%s'", requestIdEncrypted))
        // Call 1kosmos API - end encrypt
        
         lat, lon, err := GetLatest1kEvent(api, oneKosmosLicenseKeyEncrypted, requestIdEncrypted, ECDSAPublicKey, req)
    if err != nil {
        fmt.Println("Error:", err)
    } else {
        fmt.Printf("Latitude: %f, Longitude: %f\n", lat, lon)
        if lat == 0.0 || lon == 0.0 {
        logger.Error("se", "Latitude or Longitude is zero. User has not enabled location for Blockid app. Failing authentication.")
        return false
    }
    }
    
    geoLocationResponse := GeolocationTranslation(api, lat, lon, GeolocationApiKey)
        	logger.Info("se", fmt.Sprintf("Geolocation Translation API Response: '%s'", geoLocationResponse))
        	
    var geoLocations []GeoLocation

err = json.Unmarshal([]byte(geoLocationResponse), &geoLocations)
if err != nil {
    logger.Error("Error unmarshalling geolocation response:", err)
}

  if len(geoLocations) > 0 {
    name := geoLocations[0].Name
    country := geoLocations[0].Country
    state := geoLocations[0].State
    logger.Info("se", fmt.Sprintf("City: %s, Country: %s, State: %s", name, country, state))
    Test := "IN"
    if country != Test {
       logMessage := fmt.Sprintf("User is logging in from country: %s, which is not allowed to access the app.", country)
  logger.Error("se", logMessage)

              return false // Return false if they do not match
      }

    
}

		
		return true
	}

	logger.Info("se", "User not authenticated yet")
	return false
}

func GetLatest1kEvent(api orchestrator.Orchestrator, oneKosmosLicenseKeyEncrypted string, requestIdEncrypted string, ECDSAPublicKey string, req *http.Request) (float64, float64, error) {
    logger := api.Logger()
    logger.Info("se", "Fetching latest 1Kosmos event - start")

    url := "https://blockid-pilot.1kosmos.net/reports/tenant/6241af5462a87240e1479b65/community/65f059f8534aab5c373a9887/events"
    method := "POST"

    // Call BuildTokenClaims to get user claims
    claims, err := BuildTokenClaims(api, req)
    if err != nil {
        logger.Error("se", "error retrieving token claims", "error", err.Error())
        return 0, 0, errors.New("error occurred")
    }

    // Extract the user email from claims
    userEmail, ok := claims["email_1k"].(string)
    LastName, ok := claims["LastName"].(string)
    
    logger.Info(fmt.Sprintf("The email id from saml claim : %s", userEmail))
    logger.Info(fmt.Sprintf("The LastName from saml claim is : %s", LastName))
    if !ok || userEmail == "" {
        logger.Error("se", "user email not found in token claims")
        return 0, 0, errors.New("error occurred")
    }

    
    fromTime := time.Now().Add(-1 * time.Hour).Format("2006-01-02 15:04:05.000")
toTime := time.Now().Add(24 * time.Hour).Format("2006-01-02 15:04:05.000")

    // Constructing the JSON payload
    payload := map[string]interface{}{
        "pSize":  10,
        "pIndex": 0,
        "from":   fromTime,
        "to":     toTime,
        "query": map[string]string{
            "event_name":         "E_LOGIN_SUCCEEDED",
            "eventData.user_email": userEmail,
        },
        "text": `"event_name" "username"`,
    }

    // Convert payload to JSON
    jsonPayload, err := json.Marshal(payload)
    if err != nil {
        logger.Error("Error marshalling JSON payload:", err)
        return 0, 0, errors.New("error occurred")
    }

    client := &http.Client{}
    apiReq, err := http.NewRequest(method, url, bytes.NewBuffer(jsonPayload))
if err != nil {
    logger.Error("Error creating request:", err)
    return 0, 0, errors.New("error occurred")
}

    logger.Info("oneKosmosLicenseKeyEncrypted in GetLatest1kEvent: %s", oneKosmosLicenseKeyEncrypted)
    logger.Info("requestIdEncrypted in GetLatest1kEvent: %s", requestIdEncrypted)

    // Adding headers
    apiReq.Header.Set("Accept", "application/json")
    apiReq.Header.Set("Content-Type", "application/json")
    apiReq.Header.Set("licensekey", oneKosmosLicenseKeyEncrypted)
    apiReq.Header.Set("requestid", requestIdEncrypted)
    apiReq.Header.Set("publickey", ECDSAPublicKey)

    // Execute the request
    res, err := client.Do(apiReq)
    if err != nil {
        logger.Error("Error making request:", err)
        return 0, 0, errors.New("error occurred")
    }
    defer res.Body.Close()

    // Check HTTP status code
    if res.StatusCode != http.StatusOK {
        body, _ := ioutil.ReadAll(res.Body)
        logger.Error("Received non-200 response:", res.StatusCode, string(body))
        return 0, 0, errors.New("error occurred")
    }

    // Read response body
    body, err := ioutil.ReadAll(res.Body)
    if err != nil {
        logger.Error("Error reading response body:", err)
        return 0, 0, errors.New("error occurred")
    }

    // Log the raw response for debugging
    logger.Info("Response body:", string(body))

    // Parse response JSON
    var response struct {
        Data []struct {
            EventTS int64   `json:"event_ts"` // Change to string if needed
            AuthLat float64 `json:"auth_device_latitude"` // Change to float64
            AuthLon float64 `json:"auth_device_longitude"` // Change to float64
        } `json:"data"`
    }

    err = json.Unmarshal(body, &response)
    if err != nil {
        logger.Error("Error unmarshalling response:", err)
        return 0, 0, errors.New("error occurred")
    }

    // Sort events by timestamp in descending order
    sort.Slice(response.Data, func(i, j int) bool {
        return response.Data[i].EventTS > response.Data[j].EventTS
    })

    // Get the latest event if available
    if len(response.Data) > 0 {
        latestEvent := response.Data[0]
        seconds := latestEvent.EventTS / 1000
        t := time.Unix(seconds, 0)
        formattedTime := t.Format("2006-01-02 15:04:05")
        logger.Info("The latest event for user %s occurred at timestamp %s with a latitude of %f and longitude of %f", userEmail, formattedTime, latestEvent.AuthLat, latestEvent.AuthLon)
        logMessage := fmt.Sprintf("The latest event for user %s occurred at timestamp %s with a latitude of %f. and longitude of %f.", userEmail, formattedTime, latestEvent.AuthLat, latestEvent.AuthLon)
    logger.Info(logMessage)

        return latestEvent.AuthLat, latestEvent.AuthLon, nil
    }

    logger.Info("No events found.")
    return 0, 0, errors.New("No events found")
}



// Call 1Kosmos API - Encrypt input data
func EncryptData(api orchestrator.Orchestrator, inputData string, ecdsaPrivateKey string) string {
	logger := api.Logger()
	logger.Info("se", "Start Encrypt Data")

	
	baseHeader := map[string]string{
		"Accept": "application/json",
	}

	
	publicKeyURL := "https://blockid-pilot.1kosmos.net/reports/publickeys"

	// Create a new HTTP client
	client := &http.Client{}

	// Create a new request
	req, err := http.NewRequest("GET", publicKeyURL, nil)
	if err != nil {
		logger.Error("Error creating request to fetch public key:", err)
		return ""
	}

	// Set the headers
	for key, value := range baseHeader {
		req.Header.Set(key, value)
	}

	// Execute the request
	res, err := client.Do(req)
	if err != nil {
		logger.Error("Error making request to fetch public key:", err)
		return ""
	}
	defer res.Body.Close()

	// Check HTTP status code
	if res.StatusCode != http.StatusOK {
		body, _ := ioutil.ReadAll(res.Body)
		logger.Error("Received non-200 response while fetching public key:", res.StatusCode, string(body))
		return ""
	}

	// Read response body
	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		logger.Error("Error reading response body while fetching public key:", err)
		return ""
	}

	// Log the raw response for debugging
	logger.Info("Public Key Response body:", string(body))

	// Parse response JSON to get the public key
	var publicKeyResponse struct {
		PublicKey string `json:"publicKey"` // Adjust the field name based on the actual response structure
	}
	err = json.Unmarshal(body, &publicKeyResponse)
	if err != nil {
		logger.Error("Error unmarshalling public key response:", err)
		return ""
	}

	// Step 2: Define the payload for encryption
	url := "https://blockid-pilot.1kosmos.net/reports/ecdsa_helper/encrypt"
	method := "POST"
	payload := map[string]string{
		"dataStr":   inputData,
		"publicKey": publicKeyResponse.PublicKey, // Use the fetched public key
		"privateKey": ecdsaPrivateKey,
	}

	// Marshal the payload to JSON
	jsonData, err := json.Marshal(payload)
	if err != nil {
		logger.Error("Error marshaling JSON:", err)
		return ""
	}

	// Create a new HTTP POST request
	req, err = http.NewRequest(method, url, bytes.NewBuffer(jsonData))
	if err != nil {
		logger.Error("Error creating request for encryption:", err)
		return ""
	}

	// Set the required headers
	req.Header.Set("accept", "application/json")
	req.Header.Set("Content-Type", "application/json")

	// Execute the request
	resp, err := client.Do(req)
	if err != nil {
		logger.Error("Error executing request for encryption:", err)
		return ""
	}
	defer resp.Body.Close()

	// Read the response body
	body, err = ioutil.ReadAll(resp.Body)
	if err != nil {
		logger.Error("Error reading response body for encryption:", err)
		return ""
	}

	// Print the response body
	logger.Info("Encryption Response body: %s", string(body))

	// Unmarshal the JSON response into the ResponseData struct
	var responseData struct {
		EncryptedData string `json:"data"`
	}
	if err := json.Unmarshal(body, &responseData); err != nil {
		logger.Error("Erzror occurred during unmarshaling encryption response. Error: %s", err.Error())
		return ""
	}

	// Use the responseData struct
	logger.Info("Encrypted - responseData: %s", responseData)
	logger.Info("Encrypted - responseData.EncryptedData: %s", responseData.EncryptedData)
	logger.Info("se", "End Encrypt Data")
	return responseData.EncryptedData
}

func toJSON(v interface{}) string {
	bytes, err := json.Marshal(v)
	if err != nil {
		return ""
	}
	return string(bytes)
}

func BuildTokenClaims(api orchestrator.Orchestrator, _ *http.Request) (map[string]any, error) {
    logger := api.Logger()
    session, err := api.Session()
    if err != nil {
        logger.Error("se", "unable to retrieve session", "error", err.Error())
        return nil, err
    }

    // Retrieve roles from the session
    roles, _ := session.GetString("1k.roles")

    // Retrieve the email from the session using the specific key
    userEmail1, _ := session.GetString("1k.mail") 
    LastName, _ := session.GetString("1k.LN")
    Mobile, _ := session.GetString("1k.Mobile")
    BEMSID, _ := session.GetString("1k.BEMSID")
    BEMSID_Entra, _ := session.GetString("EntraIDP.BEMSID")
    userEmail2, _ := session.GetString("EntraIDP.emailaddress") 
    userEmail3, _ := session.GetString("WSSO.mail")
    
    
    // Create a map to hold the claims
    claims := map[string]any{
        "scope": roles,
        "email_1k": userEmail1, // Include the email in the claims
        "LastName": LastName,
        "Mobile" : Mobile,
        "BEMSID_1K" : BEMSID,
        "BEMSID_Entra" : BEMSID_Entra,
        "email_Entra": userEmail2,
        "email_WSSO": userEmail3,
    }

    return claims, nil
}

func GeolocationTranslation(api orchestrator.Orchestrator, userLatitude float64, userLongitude float64, GeolocationApiKey string) string {
    logger := api.Logger()
	logger.Info("se", "Start GeolocationTranslation")

    lat := fmt.Sprintf("%f", userLatitude) // Convert float64 to string(userLatitude)
	lon := fmt.Sprintf("%f", userLongitude) // Convert float64 to string(userLongitude)
	apiKey := GeolocationApiKey
	logger.Info("GeolocationTranslation lat: %s", lat)
	logger.Info("GeolocationTranslation lon: %s", lon)
	url := fmt.Sprintf("https://api.api-ninjas.com/v1/reversegeocoding?lat=%s&lon=%s", lat, lon)

	client := &http.Client{}
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		fmt.Println("Request creation failed:", err)
		return ""
	}

	req.Header.Add("X-Api-Key", apiKey)

	resp, err := client.Do(req)
	if err != nil {
		fmt.Println("Request failed:", err)
		return ""
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		fmt.Printf("Error: %d\n", resp.StatusCode)
		bodyBytes, _ := ioutil.ReadAll(resp.Body)
		fmt.Println(string(bodyBytes))
		return ""
	}

	bodyBytes, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Println("Reading body failed:", err)
		return ""
	}

	fmt.Println(string(bodyBytes))
	logger.Info("GeolocationTranslation response: %s", string(bodyBytes))
	logger.Info("se", "End GeolocationTranslation")
	return string(bodyBytes)
}