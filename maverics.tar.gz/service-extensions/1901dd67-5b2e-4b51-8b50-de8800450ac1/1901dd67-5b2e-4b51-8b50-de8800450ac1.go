package main

import (
    "fmt"
    "io/ioutil"
    "net/http"
    "net/url"
    "strings"
    "github.com/strata-io/service-extension/orchestrator"
    "encoding/json"
)


const (
    clientID     = "57194aafc618ad531220b4a4ac6cb105"
    clientSecret = "aa23150de41c4a501595a827c7860c8bbdaaec33b4bdae43b4dd79969b06c234"
    authURL      = "https://blockid-pilot.1kosmos.net/oauth2/community/ey-dev/v1/authorize"
    tokenURL     = "https://blockid-pilot.1kosmos.net/oauth2/community/ey-dev/v1/token"
    redirectURI  = "https://maverics.sonarsystems.com/1kosmos/oidc" 
    scope        = "email openid profile /assurance/ial/2/"
)


func IdentityProofingHandler(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
    if req.Method == http.MethodGet {
        
        initiateProofing(rw)
    } else if req.Method == http.MethodPost {
       
        handleCallback(api, rw, req)
    } else {
        http.Error(rw, "Unsupported HTTP method", http.StatusMethodNotAllowed)
    }
}


func initiateProofing(rw http.ResponseWriter) {
    authRedirectURL := fmt.Sprintf("%s?response_type=code&client_id=%s&redirect_uri=%s&scope=%s",
        authURL, clientID, redirectURI, url.QueryEscape(scope))
    http.Redirect(rw, nil, authRedirectURL, http.StatusFound)
}


func handleCallback(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
    logger := api.Logger()

    code := req.URL.Query().Get("code")
    if code == "" {
        http.Error(rw, "Missing authorization code", http.StatusBadRequest)
        return
    }

    // Prepare token request data
    data := url.Values{}
    data.Set("grant_type", "authorization_code")
    data.Set("client_id", clientID)
    data.Set("client_secret", clientSecret)
    data.Set("code", code)
    data.Set("redirect_uri", redirectURI)

    
    resp, err := http.Post(tokenURL, "application/x-www-form-urlencoded", strings.NewReader(data.Encode()))
    if err != nil {
        logger.Error("se", "Token exchange failed", "error", err.Error())
        http.Error(rw, "Failed to exchange token", http.StatusInternalServerError)
        return
    }
    defer resp.Body.Close()

    
    body, err := ioutil.ReadAll(resp.Body)
    if err != nil {
        logger.Error("se", "Failed to read token response", "error", err.Error())
        http.Error(rw, "Failed to read token response", http.StatusInternalServerError)
        return
    }

    var tokenResponse map[string]interface{}
    if err := json.Unmarshal(body, &tokenResponse); err != nil {
        logger.Error("se", "Failed to parse token response", "error", err.Error())
        http.Error(rw, "Failed to parse token response", http.StatusInternalServerError)
        return
    }

    
    if assurance, ok := tokenResponse["assurance"].(string); ok && assurance == "IAL2" {
        logger.Info("se", "User identity proofing successful", "assurance", assurance)
        rw.Write([]byte("Identity proofing successful"))
    } else {
        logger.Error("se", "User did not meet IAL2 level", "assurance", tokenResponse["assurance"])
        http.Error(rw, "Identity proofing level not sufficient", http.StatusUnauthorized)
    }
}

func main() {
    
    http.HandleFunc("/identity-proofing", func(rw http.ResponseWriter, req *http.Request) {
        api := orchestrator.NewOrchestrator() 
        IdentityProofingHandler(api, rw, req)
    })

    http.ListenAndServe(":8080", nil)
}
