package main

import (
    "fmt"
    "io/ioutil"
    "net/http"
    "net/url"
    "strings"
    "github.com/strata-io/service-extension/orchestrator"
    "encoding/json"
)

// Configuration details
const (
    clientID     = "57194aafc618ad531220b4a4ac6cb105"
    clientSecret = "aa23150de41c4a501595a827c7860c8bbdaaec33b4bdae43b4dd79969b06c234"
    authURL      = "https://blockid-pilot.1kosmos.net/oauth2/community/ey-dev/v1/authorize"
    tokenURL     = "https://blockid-pilot.1kosmos.net/oauth2/community/ey-dev/v1/token"
    redirectURI  = "https://yourapp.com/callback" // Replace with your actual callback URL
    scope        = "email openid profile /assurance/ial/2/"
)

// IdentityProofingHandler handles both initiating proofing and processing the callback.
func IdentityProofingHandler(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
    if req.Method == http.MethodGet {
        // Step 1: Redirect to 1Kosmos for Identity Proofing
        initiateProofing(rw)
    } else if req.Method == http.MethodPost {
        // Step 2: Handle Callback and Token Exchange
        handleCallback(api, rw, req)
    } else {
        http.Error(rw, "Unsupported HTTP method", http.StatusMethodNotAllowed)
    }
}

// initiateProofing redirects the user to the 1Kosmos authorization URL.
func initiateProofing(rw http.ResponseWriter) {
    authRedirectURL := fmt.Sprintf("%s?response_type=code&client_id=%s&redirect_uri=%s&scope=%s",
        authURL, clientID, redirectURI, url.QueryEscape(scope))
    http.Redirect(rw, nil, authRedirectURL, http.StatusFound)
}

// handleCallback exchanges the authorization code for a token and validates proofing.
func handleCallback(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
    logger := api.Logger()

    code := req.URL.Query().Get("code")
    if code == "" {
        http.Error(rw, "Missing authorization code", http.StatusBadRequest)
        return
    }

    // Prepare token request data
    data := url.Values{}
    data.Set("grant_type", "authorization_code")
    data.Set("client_id", clientID)
    data.Set("client_secret", clientSecret)
    data.Set("code", code)
    data.Set("redirect_uri", redirectURI)

    // Exchange authorization code for access token
    resp, err := http.Post(tokenURL, "application/x-www-form-urlencoded", strings.NewReader(data.Encode()))
    if err != nil {
        logger.Error("se", "Token exchange failed", "error", err.Error())
        http.Error(rw, "Failed to exchange token", http.StatusInternalServerError)
        return
    }
    defer resp.Body.Close()

    // Parse token response
    body, err := ioutil.ReadAll(resp.Body)
    if err != nil {
        logger.Error("se", "Failed to read token response", "error", err.Error())
        http.Error(rw, "Failed to read token response", http.StatusInternalServerError)
        return
    }

    var tokenResponse map[string]interface{}
    if err := json.Unmarshal(body, &tokenResponse); err != nil {
        logger.Error("se", "Failed to parse token response", "error", err.Error())
        http.Error(rw, "Failed to parse token response", http.StatusInternalServerError)
        return
    }

    // Validate IAL Level in the token
    if assurance, ok := tokenResponse["assurance"].(string); ok && assurance == "IAL2" {
        logger.Info("se", "User identity proofing successful", "assurance", assurance)
        rw.Write([]byte("Identity proofing successful"))
    } else {
        logger.Error("se", "User did not meet IAL2 level", "assurance", tokenResponse["assurance"])
        http.Error(rw, "Identity proofing level not sufficient", http.StatusUnauthorized)
    }
}

func main() {
    // Example setup in the main function to register the handler
    http.HandleFunc("/identity-proofing", func(rw http.ResponseWriter, req *http.Request) {
        api := orchestrator.NewOrchestrator() // Assuming this initializes Orchestrator in your environment
        IdentityProofingHandler(api, rw, req)
    })

    http.ListenAndServe(":8080", nil)
}
