package main

import (
    "fmt"
    "net/http"
    "github.com/strata-io/service-extension/orchestrator"
)

func InitiateProofing(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) {
    clientID := "57194aafc618ad531220b4a4ac6cb105"
    redirectURI := "https://yourapp.com/callback" // Update with your actual callback URL
    scope := "email openid profile /assurance/ial/2/"

    // Build authorization URL
    authURL := fmt.Sprintf("https://blockid-pilot.1kosmos.net/oauth2/community/ey-dev/v1/authorize?response_type=code&client_id=%s&redirect_uri=%s&scope=%s", clientID, redirectURI, scope)

    // Redirect user to 1Kosmos for identity proofing
    http.Redirect(rw, req, authURL, http.StatusFound)
}
